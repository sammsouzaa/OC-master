"""
main.py — ponto de entrada.   Rodar:  python3 main.py

Estrutura:
    funcao.py    Função 8, limites, arredondar(), limitar()
    ag.py        seleção ranking, BLX-alpha, mutação uniforme, elitismo, loop
    graficos.py  gráfico da população por geração + linha do fitness médio
    log.py       CSV (geracao, fitness_medio, melhor_fitness, melhor_x, melhor_y)
    interface.py janela tkinter com os parâmetros
    saida/       PNGs gerados por geração

Dependência externa: matplotlib   (pip install matplotlib)
tkinter vem com o Python (no Linux: sudo apt install python3-tk).

Sugestão de ordem de implementação (testando cada etapa sozinha):
    1. funcao.py  -> testar fitness(0.667, -1.667) ≈ 9.333
    2. ag.py: população inicial + avaliar
    3. ag.py: ranking, BLX, mutação, elitismo (testar cada um isolado)
    4. ag.py: executar_ag (sem gráficos, imprimindo no terminal)
    5. log.py e graficos.py
    6. interface.py
"""

import interface

if __name__ == "__main__":
    interface.iniciar()
