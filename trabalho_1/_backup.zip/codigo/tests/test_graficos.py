"""
test_graficos.py — testes de graficos.py.

Gráfico é difícil de testar visualmente; teste o que dá: o arquivo foi
criado e não está vazio. O resto confira a olho (abra o PNG).

Importante: use backend Agg (matplotlib.use("Agg")) para não abrir janelas.
"""

import os
import tempfile
import unittest

import matplotlib

matplotlib.use("Agg")

import graficos  # noqa: E402


class TestGraficoPopulacao(unittest.TestCase):
    def test_gera_png(self):
        """grafico_populacao(..., caminho) cria um arquivo PNG não vazio.

        TODO: população pequena fake + tempfile.TemporaryDirectory().
        """
        self.skipTest("TODO")

    def test_nao_deixa_figuras_abertas(self):
        """Após chamar várias vezes, plt.get_fignums() == [] (sem vazamento
        de memória; precisa de plt.close(fig)).

        TODO
        """
        self.skipTest("TODO")


class TestGraficoFitnessMedio(unittest.TestCase):
    def test_gera_png(self):
        """grafico_fitness_medio(..., caminho) cria um PNG não vazio.

        TODO
        """
        self.skipTest("TODO")

    def test_aceita_sem_melhor_fitness(self):
        """O parâmetro melhor_fitness é opcional (None).

        TODO
        """
        self.skipTest("TODO")


if __name__ == "__main__":
    unittest.main()
