"""
test_funcao.py — testes de funcao.py.

Rodar tudo (dentro de codigo/):   python3 -m unittest discover -v
Rodar só este arquivo:            python3 -m unittest tests.test_funcao -v

Cada teste começa PULADO (skipTest). Ao implementar o teste, apague a linha
self.skipTest(...) correspondente.
"""

import unittest

import funcao


class TestFitness(unittest.TestCase):
    def test_otimo_conhecido(self):
        """fitness(0.667, -1.667) deve ficar perto de 9.333 (tolerância ~0.01).

        TODO: assertAlmostEqual(..., places=2) ou delta=0.01
        """
        self.skipTest("TODO")

    def test_valor_em_ponto_simples(self):
        """Confira à mão um ponto fácil, ex.: (0, 0) -> 5.

        TODO: pelo menos mais um ponto calculado no papel (ex.: (1, 1)).
        """
        self.skipTest("TODO")

    def test_otimo_e_maximo_local_vizinho(self):
        """Pontos vizinhos ao ótimo devem ter fitness MENOR (é maximização).

        TODO: comparar fitness(otimo) > fitness(otimo + deslocamento) em
        algumas direções.
        """
        self.skipTest("TODO")


class TestArredondar(unittest.TestCase):
    def test_tres_casas(self):
        """arredondar(1.23456) -> 1.235.

        TODO: assertEqual com valor esperado.
        """
        self.skipTest("TODO")

    def test_ja_arredondado_nao_muda(self):
        """arredondar(2.5) -> 2.5.

        TODO
        """
        self.skipTest("TODO")


class TestLimitar(unittest.TestCase):
    def test_dentro_do_intervalo_nao_muda(self):
        """limitar(3.0) -> 3.0.

        TODO
        """
        self.skipTest("TODO")

    def test_acima_do_maximo(self):
        """limitar(15) -> LIMITE_MAX.

        TODO
        """
        self.skipTest("TODO")

    def test_abaixo_do_minimo(self):
        """limitar(-15) -> LIMITE_MIN.

        TODO
        """
        self.skipTest("TODO")

    def test_bordas_exatas(self):
        """limitar(LIMITE_MIN) e limitar(LIMITE_MAX) não mudam.

        TODO
        """
        self.skipTest("TODO")


if __name__ == "__main__":
    unittest.main()
