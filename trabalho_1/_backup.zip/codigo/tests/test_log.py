"""
test_log.py — testes de log.py (CSV exigido pelo enunciado).

Dica: use tempfile.TemporaryDirectory() para não sujar o projeto.
"""

import csv
import os
import tempfile
import unittest

import log


class TestSalvarLog(unittest.TestCase):
    def historico_exemplo(self):
        """Histórico mínimo de 3 gerações.

        TODO: montar o dict com as chaves usadas por ag.executar_ag.
        """
        raise NotImplementedError

    def test_cabecalho(self):
        """Primeira linha == log.COLUNAS.

        TODO
        """
        self.skipTest("TODO")

    def test_uma_linha_por_geracao(self):
        """Linhas de dados == número de gerações.

        TODO
        """
        self.skipTest("TODO")

    def test_valores_gravados_corretamente(self):
        """Valores da 1ª e da última linha batem com o histórico.

        TODO
        """
        self.skipTest("TODO")

    def test_arquivo_pode_ser_relido(self):
        """csv.reader consegue ler de volta (delimitador consistente).

        TODO
        """
        self.skipTest("TODO")


if __name__ == "__main__":
    unittest.main()
