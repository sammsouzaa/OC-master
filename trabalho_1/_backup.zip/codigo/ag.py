"""
ag.py — núcleo do Algoritmo Genético (Equipe 9).

Especificação FIXA da equipe (não trocar):
    Codificação : Real        (indivíduo = par (x, y) de floats)
    Seleção     : Ranking
    Cruzamento  : BLX-alpha
    Mutação     : Uniforme
    Elitismo    : 0,5% do tamanho da população
    Função      : 8 (maximização) -> ver funcao.py

PROIBIDO: bibliotecas/códigos prontos de AG (DEAP, PyGAD, GitHub...) e código
gerado por LLM. Pode usar: random, math, statistics, ordenação, csv, etc.

Fluxo de executar_ag():
    inicializa -> loop de gerações { avalia, loga, desenha, elite,
    (seleciona -> cruza -> muda)*, nova população, checa convergência }
"""

import random
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

import funcao

# Um indivíduo é uma tupla (x, y). Se preferir, troque por uma classe/dataclass
# com campos x, y, fitness (evita recalcular o fitness várias vezes).
Individuo = Tuple[float, float]


@dataclass
class Parametros:
    """Parâmetros vindos da INTERFACE (obrigatório pelo enunciado)."""
    tamanho_populacao: int
    num_geracoes: int
    taxa_cruzamento: float   # probabilidade de um par de pais cruzar (0 a 1)
    taxa_mutacao: float      # probabilidade de mutar CADA GENE (0 a 1)
    alpha: float = 0.5       # extra: parâmetro do BLX-alpha (0.5 é o clássico)
    # Extras opcionais para o critério de convergência (ver convergiu()):
    limiar_diversidade: float = 0.001
    geracoes_sem_melhora: int = 30


# --------------------------------------------------------------------------
# População inicial
# --------------------------------------------------------------------------
def criar_populacao_inicial(n: int) -> List[Individuo]:
    """Cria n indivíduos sorteando x e y uniformemente em [LIMITE_MIN, LIMITE_MAX].

    TODO:
      - random.uniform(...) para cada gene
      - funcao.arredondar() em cada gene (3 casas)
    """
    raise NotImplementedError


def avaliar(populacao: List[Individuo]) -> List[float]:
    """Retorna a lista de fitness, na MESMA ordem da população.

    TODO: funcao.fitness(x, y) para cada indivíduo.
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Seleção por RANKING
# --------------------------------------------------------------------------
def selecionar_por_ranking(populacao: List[Individuo],
                           fitnesses: List[float]) -> Individuo:
    """Sorteia UM pai usando seleção por ranking.

    Ideia (ranking linear simples):
      1. ordene os índices pelo fitness CRESCENTE: pior = rank 1, melhor = rank N
         (é maximização! rank maior = melhor. Cuidado para não inverter.)
      2. probabilidade de cada um = rank / soma(1..N)
      3. sorteie proporcionalmente a essas probabilidades
         (dica: random.choices(..., weights=ranks) ou roleta manual)

    DIFERENÇA para a roleta: aqui o peso é o RANK, nunca o valor do fitness.
    Fitness negativo/muito diferente não atrapalha, essa é a vantagem.

    Recomendação: calcule os ranks UMA vez por geração (função auxiliar)
    em vez de reordenar a cada sorteio, é mais eficiente.
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Cruzamento BLX-alpha
# --------------------------------------------------------------------------
def cruzar_blx_alpha(pai1: Individuo, pai2: Individuo, alpha: float,
                     taxa_cruzamento: float) -> Tuple[Individuo, Individuo]:
    """Gera 2 filhos com BLX-alpha, aplicado POR GENE (x e y separados).

    Regra da aula: sorteia-se alfa_sorteio em [0, 1]; se alfa_sorteio < taxa_cruzamento,
    cruza; senão os pais passam adiante sem alteração.
    (Não confundir alfa_sorteio com o `alpha` do BLX.)
    Se cruzar:
        para cada gene g (x depois y):
            d  = |p1[g] - p2[g]|
            lo = min(p1[g], p2[g]) - alpha * d
            hi = max(p1[g], p2[g]) + alpha * d
            filho[g] = random.uniform(lo, hi)
        -> sorteie de novo para o 2º filho
    Caso contrário: filhos = cópias dos pais.

    OBRIGATÓRIO no fim: funcao.limitar() e funcao.arredondar() em cada gene.
    (lo/hi podem sair de [-10, 10].)
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Mutação Uniforme
# --------------------------------------------------------------------------
def mutar_uniforme(individuo: Individuo, taxa_mutacao: float) -> Individuo:
    """Mutação uniforme, gene a gene.

    Aplicada aos FILHOS. Para cada gene: sorteia-se alfa em [0, 1]; se
    alfa < taxa_mutacao, substitua por random.uniform(LIMITE_MIN, LIMITE_MAX).
    Senão mantém. Arredonde em 3 casas.
    Faixa típica da aula: 0.01 a 0.05.

    Atenção: a taxa é POR GENE (não por indivíduo). Documente isso.
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Elitismo (0,5% da população)
# --------------------------------------------------------------------------
def calcular_tamanho_elite(tamanho_populacao: int) -> int:
    """n_elite = 0,5% * tamanho_populacao.

    PROBLEMA: população 100 -> 0,5 indivíduo. Defina e DOCUMENTE uma regra.
    Sugestão: max(1, round(0.005 * n)). Confirme com o professor.
    """
    raise NotImplementedError


def extrair_elite(populacao: List[Individuo], fitnesses: List[float],
                  n_elite: int) -> List[Individuo]:
    """Retorna os n_elite melhores indivíduos (maior fitness).

    TODO: ordenar índices por fitness decrescente (sorted com key=) e pegar
    os n_elite primeiros. Eles vão direto para a próxima geração, sem
    cruzar nem mutar.
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Critério de parada por convergência (opcional, além do nº de gerações)
# --------------------------------------------------------------------------
def convergiu(populacao: List[Individuo], historico_melhor: List[float],
              params: Parametros) -> bool:
    """True se a população convergiu -> parar antes de num_geracoes.

    Opções (pode usar uma ou as duas):
      a) diversidade: desvio padrão de x e y (statistics.pstdev) abaixo de
         params.limiar_diversidade
      b) estagnação: melhor fitness não melhorou nas últimas
         params.geracoes_sem_melhora gerações (olhe historico_melhor)

    NÃO use "chegou perto de 9.3333" — o enunciado proíbe (mesmo que o slide
    de aula cite "valor ótimo alcançado" como critério).
    """
    raise NotImplementedError


# --------------------------------------------------------------------------
# Loop principal
# --------------------------------------------------------------------------
def executar_ag(params: Parametros,
                ao_fim_de_geracao: Optional[Callable] = None) -> dict:
    """Roda o AG completo.

    ao_fim_de_geracao: callback chamado a cada geração com
        (geracao, populacao, fitnesses, melhor_individuo, melhor_fitness)
      -> a interface/gráficos se ligam aqui (desenhar população, atualizar
         tela). Assim ag.py NÃO depende de tkinter nem de matplotlib.

    Retorna um dict com o histórico, por exemplo:
        {"geracoes": [...], "fitness_medio": [...], "melhor_fitness": [...],
         "melhor_x": [...], "melhor_y": [...], "melhor_final": (x, y)}

    Esqueleto do loop:

        populacao = criar_populacao_inicial(params.tamanho_populacao)
        for g in range(1, params.num_geracoes + 1):
            fitnesses = avaliar(populacao)
            # 1. calcular fitness médio, melhor indivíduo, melhor fitness
            # 2. guardar no histórico (vai pro CSV e pro gráfico de linha)
            # 3. chamar ao_fim_de_geracao(...) se existir
            # 4. n_elite / extrair_elite
            # 5. while len(nova) < tamanho_populacao:
            #        pai1 = selecionar_por_ranking(...)
            #        pai2 = selecionar_por_ranking(...)
            #        f1, f2 = cruzar_blx_alpha(...)
            #        f1, f2 = mutar_uniforme(f1,...), mutar_uniforme(f2,...)
            #        nova += [f1, f2]
            #    (cuidado: população ímpar -> cortar o excedente)
            # 6. populacao = elite + nova[: tamanho - n_elite]
            # 7. if convergiu(...): break
        return historico

    Sanity check: com elitismo, o melhor fitness NUNCA pode cair.
    """
    raise NotImplementedError
