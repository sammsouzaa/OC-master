"""
log.py — grava o log por geração em CSV (exigência do enunciado).

Colunas obrigatórias: geracao, fitness_medio, melhor_fitness, melhor_x, melhor_y
"""

import csv

COLUNAS = ["geracao", "fitness_medio", "melhor_fitness", "melhor_x", "melhor_y"]


def salvar_log(historico: dict, caminho: str = "log.csv") -> None:
    """Escreve uma linha por geração.

    TODO:
      - csv.writer (ou DictWriter), abrir com newline="" e encoding="utf-8"
      - escrever o cabeçalho COLUNAS
      - uma linha por geração, lendo as listas de `historico`
        (chaves definidas em ag.executar_ag)
    Dica: se quiser o separador decimal certo para abrir no Excel pt-BR,
    use delimiter=";" — mas mantenha o mesmo formato sempre.
    """
    raise NotImplementedError
