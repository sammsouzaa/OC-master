"""
interface.py — janela tkinter (parâmetros definidos NA INTERFACE, como exige o enunciado).

A interface só LÊ os campos, monta um ag.Parametros e chama ag.executar_ag().
Nenhuma lógica do AG mora aqui.

Fluxo ao clicar em "Executar":
    1. lê e valida os parâmetros
    2. roda o AG; a cada geração o callback grava saida/geracao_XXX.png
       (graficos.grafico_populacao) e mostra a imagem na aba "População"
    3. grava log.csv (log.salvar_log)
    4. grava saida/fitness_medio.png (graficos.grafico_fitness_medio) e mostra
       na aba "Fitness médio"
"""

import glob
import os
import tkinter as tk
from tkinter import messagebox, ttk

import matplotlib

matplotlib.use("Agg")  # gráficos só viram PNG; a janela quem mostra é o tkinter

import ag  # noqa: E402
import graficos  # noqa: E402
import log  # noqa: E402

PASTA = os.path.dirname(os.path.abspath(__file__))
PASTA_SAIDA = os.path.join(PASTA, "saida")
CAMINHO_LOG = os.path.join(PASTA, "log.csv")
CAMINHO_FITNESS = os.path.join(PASTA_SAIDA, "fitness_medio.png")

# (chave, rótulo, valor padrão)
CAMPOS = [
    ("tamanho_populacao", "Tamanho da população", "100"),
    ("num_geracoes", "Número de gerações", "100"),
    ("taxa_cruzamento", "Taxa de cruzamento (0 a 1)", "0.8"),
    ("taxa_mutacao", "Taxa de mutação (0 a 1)", "0.05"),
    ("alpha", "Alpha do BLX", "0.5"),
]


class Aplicacao:
    def __init__(self, raiz: tk.Tk):
        self.raiz = raiz
        raiz.title("AG — Equipe 9 (Função 8)")
        raiz.resizable(False, False)
        self.entradas = {}
        self.imagens = {}  # guarda referência, senão o tkinter descarta a imagem
        self._montar_widgets()

    # ------------------------------------------------------------------
    # Montagem da tela
    # ------------------------------------------------------------------
    def _montar_widgets(self) -> None:
        quadro = ttk.Frame(self.raiz, padding=12)
        quadro.grid()

        # Parâmetros
        for linha, (chave, rotulo, padrao) in enumerate(CAMPOS):
            ttk.Label(quadro, text=rotulo).grid(row=linha, column=0, sticky="w", pady=2)
            entrada = ttk.Entry(quadro, width=10, justify="right")
            entrada.insert(0, padrao)
            entrada.grid(row=linha, column=1, padx=(12, 0), pady=2)
            self.entradas[chave] = entrada

        self.botao = ttk.Button(quadro, text="Executar", command=self.executar)
        self.botao.grid(row=len(CAMPOS), column=0, columnspan=2, pady=(10, 4), sticky="ew")

        self.status = tk.StringVar(value="Pronto.")
        ttk.Label(quadro, textvariable=self.status).grid(
            row=len(CAMPOS) + 1, column=0, columnspan=2, sticky="w")

        self.resultado = tk.StringVar(value="")
        ttk.Label(quadro, textvariable=self.resultado, justify="left").grid(
            row=len(CAMPOS) + 2, column=0, columnspan=2, sticky="w", pady=(6, 0))

        # Abas com os gráficos
        abas = ttk.Notebook(quadro)
        abas.grid(row=0, column=2, rowspan=len(CAMPOS) + 3, padx=(16, 0))
        self.rotulos_img = {}
        for nome in ("População", "Fitness médio"):
            aba = ttk.Frame(abas)
            rotulo = ttk.Label(aba, text="(sem gráfico ainda)", width=60, anchor="center")
            rotulo.pack(ipady=80)
            abas.add(aba, text=nome)
            self.rotulos_img[nome] = rotulo

    # ------------------------------------------------------------------
    # Leitura e validação
    # ------------------------------------------------------------------
    def _ler_parametros(self):
        """Retorna ag.Parametros ou None (e mostra o erro) se algo estiver inválido."""
        try:
            def ler(chave):
                return self.entradas[chave].get().strip().replace(",", ".")

            params = ag.Parametros(
                tamanho_populacao=int(ler("tamanho_populacao")),
                num_geracoes=int(ler("num_geracoes")),
                taxa_cruzamento=float(ler("taxa_cruzamento")),
                taxa_mutacao=float(ler("taxa_mutacao")),
                alpha=float(ler("alpha")),
            )
        except ValueError:
            messagebox.showerror("Valor inválido", "Preencha todos os campos com números.")
            return None

        erro = None
        if params.tamanho_populacao < 2:
            erro = "A população precisa ter pelo menos 2 indivíduos."
        elif params.num_geracoes < 1:
            erro = "O número de gerações precisa ser pelo menos 1."
        elif not 0 <= params.taxa_cruzamento <= 1:
            erro = "A taxa de cruzamento deve estar entre 0 e 1."
        elif not 0 <= params.taxa_mutacao <= 1:
            erro = "A taxa de mutação deve estar entre 0 e 1."
        elif params.alpha < 0:
            erro = "O alpha do BLX não pode ser negativo."
        if erro:
            messagebox.showerror("Valor inválido", erro)
            return None
        return params

    # ------------------------------------------------------------------
    # Exibição de imagens
    # ------------------------------------------------------------------
    def _mostrar_imagem(self, aba: str, caminho: str) -> None:
        imagem = tk.PhotoImage(file=caminho)  # PNG é suportado nativamente
        self.imagens[aba] = imagem
        self.rotulos_img[aba].configure(image=imagem, text="")

    # ------------------------------------------------------------------
    # Execução
    # ------------------------------------------------------------------
    def executar(self) -> None:
        params = self._ler_parametros()
        if params is None:
            return

        os.makedirs(PASTA_SAIDA, exist_ok=True)
        for antigo in glob.glob(os.path.join(PASTA_SAIDA, "geracao_*.png")):
            os.remove(antigo)  # evita sobrar PNG de uma execução anterior mais longa

        def ao_fim_de_geracao(geracao, populacao, fitnesses, melhor, melhor_fitness):
            caminho = os.path.join(PASTA_SAIDA, f"geracao_{geracao:03d}.png")
            graficos.grafico_populacao(geracao, populacao, melhor, caminho)
            self._mostrar_imagem("População", caminho)
            self.status.set(f"Geração {geracao}/{params.num_geracoes}  |  "
                            f"melhor fitness: {melhor_fitness:.4f}")
            self.raiz.update()  # mantém a janela respondendo durante o loop

        self.botao.configure(state="disabled")
        self.resultado.set("")
        self.status.set("Executando...")
        self.raiz.update()
        try:
            historico = ag.executar_ag(params, ao_fim_de_geracao)
            log.salvar_log(historico, CAMINHO_LOG)
            graficos.grafico_fitness_medio(
                historico["geracoes"], historico["fitness_medio"],
                historico["melhor_fitness"], CAMINHO_FITNESS)
            self._mostrar_imagem("Fitness médio", CAMINHO_FITNESS)
            self._mostrar_resumo(historico)
        except NotImplementedError:
            self.status.set("Pronto.")
            messagebox.showinfo("Esqueleto",
                                "Alguma parte do AG ainda não foi implementada.")
        finally:
            self.botao.configure(state="normal")

    def _mostrar_resumo(self, historico: dict) -> None:
        x, y = historico["melhor_final"]
        self.status.set(f"Concluído em {len(historico['geracoes'])} gerações.")
        self.resultado.set(f"Melhor x: {x:.3f}\n"
                           f"Melhor y: {y:.3f}\n"
                           f"Fitness: {historico['melhor_fitness'][-1]:.4f}\n"
                           f"Log: {os.path.basename(CAMINHO_LOG)}")


def iniciar() -> None:
    raiz = tk.Tk()
    Aplicacao(raiz)
    raiz.mainloop()
