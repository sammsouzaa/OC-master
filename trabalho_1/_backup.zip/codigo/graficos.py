"""
graficos.py — gráficos exigidos pelo enunciado (matplotlib).

Exigências:
  1. A CADA geração: gráfico da população no espaço de busca, com o MELHOR
     indivíduo destacado. Pode aparecer em tela ou ser gravado em disco.
  2. Ao final: gráfico de LINHA do fitness médio por geração.

Dicas:
  - Use matplotlib.use("Agg") se for só gravar PNG (mais rápido, sem janela).
    Se for embutir no tkinter, use FigureCanvasTkAgg (matplotlib.backends.backend_tkagg).
  - Fixe os eixos em [LIMITE_MIN, LIMITE_MAX] para a "animação" não pular.
  - Feche as figuras (plt.close(fig)) depois de salvar, senão estoura memória
    com muitas gerações.
"""

from typing import List, Tuple

import matplotlib.pyplot as plt

import funcao

Individuo = Tuple[float, float]


def grafico_populacao(geracao: int, populacao: List[Individuo],
                      melhor: Individuo, caminho_png: str = None):
    """Scatter dos (x, y) da população + melhor indivíduo destacado.

    TODO:
      - (opcional, fica muito bom) contourf/contour da funcao.fitness ao fundo:
        gerar grade com numpy.meshgrid ou listas, calcular Z e plotar
      - scatter da população (cor discreta)
      - scatter do melhor com cor/marcador/tamanho diferentes (ex.: estrela
        vermelha) + legenda
      - título com o número da geração, eixos fixados nos limites
      - se caminho_png: fig.savefig(caminho_png) e plt.close(fig)
    """
    raise NotImplementedError


def grafico_fitness_medio(geracoes: List[int], fitness_medio: List[float],
                          melhor_fitness: List[float] = None,
                          caminho_png: str = None):
    """Gráfico de linha: fitness médio por geração.

    TODO:
      - plot(geracoes, fitness_medio), rótulos dos eixos e título
      - (recomendado) plotar também melhor_fitness na mesma figura
      - se caminho_png: salvar; senão plt.show()
    """
    raise NotImplementedError
