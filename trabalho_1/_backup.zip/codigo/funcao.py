"""
funcao.py — Função 8 e constantes do problema.

Equipe 9. Z = 5 + 3x - 4y - x^2 + xy - y^2, x e y em [-10, 10].
Problema de MAXIMIZAÇÃO. Ótimo conhecido: x=0.6667, y=-1.6667, z=9.3333
(use só para CONFERIR o resultado; NÃO pode ser critério de parada).
"""

# Limites do espaço de busca (iguais para x e y)
LIMITE_MIN = -10.0
LIMITE_MAX = 10.0

# Casas decimais exigidas pelo enunciado para representação real
CASAS_DECIMAIS = 3


def fitness(x: float, y: float) -> float:
    """Retorna Z = 5 + 3x - 4y - x^2 + xy - y^2.

    TODO: implementar a fórmula.
    Dica: como é maximização, fitness maior = indivíduo melhor.
    """
    raise NotImplementedError


def arredondar(valor: float) -> float:
    """Arredonda para CASAS_DECIMAIS casas.

    TODO: implementar (uma linha com round()).
    Chame isto depois de TODO operador genético (init, cruzamento, mutação).
    """
    raise NotImplementedError


def limitar(valor: float) -> float:
    """Clamp: força o valor a ficar dentro de [LIMITE_MIN, LIMITE_MAX].

    TODO: implementar.
    Obrigatório após o BLX-α, que pode gerar filhos fora do intervalo.
    """
    raise NotImplementedError
